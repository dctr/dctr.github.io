/*
 * Panel Commands by David Christ <david.christ@uni-trier.de>.
 *
 * This small piece of an extension gives you a menu in the panel, from which you can run commands.
 * In addition, it supports text entries and separator lines in this menu.
 * To create your custom menu, you have to edit this file where it tells you to.
 *
 * To edit the menu, scroll down to the comment shouting "Edit here to alter the menu".
 * Search for "Edit here to alter the icon" in order to change the icon displayed in the panel.
 *
 * Thanks to gcampax (https://extensions.gnome.org/accounts/profile/gcampax) for most of the code ;-)
 */

// To execute commands.
const GLib = imports.gi.GLib;

// To add stuff to the Panel.
const Main = imports.ui.main;
const PanelMenu = imports.ui.panelMenu;
const PopupMenu = imports.ui.popupMenu;

// To localize texts, if possible.
const Gettext = imports.gettext.domain('gnome-shell-extensions');
const _ = Gettext.gettext;

function Indicator() {
    this._init.apply(this, arguments);
}

Indicator.prototype = {
    __proto__: PanelMenu.SystemStatusButton.prototype,

    _init: function() {
    	//
    	// +------------------------------+
    	// | Edit here to alter the icon. |
    	// +------------------------------+
    	//
    	// For the initial (`disper`) purposes, the monitor icon suites well here.
    	// To get a different logo, you can change the string to some other known "class" of icon.
    	// Many of them (all?) can be found via the command below. But not all of the listes ones have an icon, that is small enough.
    	// Those entries _might_ have suitable sized icons. The label itself is the searches "class", so just test them out.
    	//grep "<g inkscape:label" /usr/share/icons/gnome/scalable/actions/edit-select-all-symbolic.svg
    	// Please contact me, if you chan help me writing some better stuff here ;-)
    	//
    	// Some icons i found working (exactly one has to be commented out at any time):
        //PanelMenu.SystemStatusButton.prototype._init.call(this, 'preferences-desktop-display'); // The Monitor Icon.
        //PanelMenu.SystemStatusButton.prototype._init.call(this, 'utilities-terminal'); // The Terminal Icon.
        //PanelMenu.SystemStatusButton.prototype._init.call(this, 'help-browser'); // A weird wheel.
        //PanelMenu.SystemStatusButton.prototype._init.call(this, 'start-here'); // The gnome foot.
        PanelMenu.SystemStatusButton.prototype._init.call(this, 'emblem-favorite'); // A Heart.
        //PanelMenu.SystemStatusButton.prototype._init.call(this, 'ADD YOU ICON HERE'); // 42.
        this._createMenu();
    },

    _createMenu: function() {
    	//
	    // +------------------------------+
    	// | Edit here to alter the menu. |
    	// +------------------------------+
    	// Order is of course relevant ;-)
    	// Note: If you are using a localizable string, like e.g. "Configure display settings...", it will be translated.
    	//
    	// To insert a separator line, add:
    	//this._addSeparator();
    	//
    	// To insert a bold text (like a headline, not clickable), add:
    	//this._addBoldText("YOUR TEXT HERE");
		//
    	// To insert an item which executes the respective command on click, add:
    	//this._addCommand("YOUR DESCRIPTION", "command");

		// My example: A menu to access disper commands and a quick access to the terminal.
        this._addBoldText("Disper Commands");
        this._addCommand("Internal Display", "disper --single");
        this._addCommand("External Display", "disper --secondary");
        this._addCommand("Both Displays", "disper --extend");
        this._addSeparator();
		this._addCommand("THE Internet", "firefox & evolution & empathy");
        this._addCommand("New Mail", "evolution mailto:");
        this._addCommand("Gnome Terminal", "gnome-terminal");
        this._addCommand("Systemupdate", "gnome-terminal -e 'pacman -Syu'");
    },


    _addSeparator: function() {
	    // Make a separator.
    	this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
    },

    _addBoldText: function(text) {
    	// Insert a bold text.
    	let item = new PopupMenu.PopupMenuItem(_(text));
        item.label.add_style_class_name('bold-text');
        item.actor.reactive = false;
        item.actor.can_focus = false;
        this.menu.addMenuItem(item);
    },

    _addCommand: function(label, command) {
    	// Insert a starter.
    	this.menu.addAction(_(label), function() { GLib.spawn_command_line_async(command); });
    },
}


function init() {}

let _indicator;

function enable() {
    _indicator = new Indicator();
    Main.panel.addToStatusArea('display', _indicator);
}

function disable() {
    _indicator.destroy();
}
